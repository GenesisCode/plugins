Title: Web social icons

Author:  NarjisNaqvi
                 http://narjisnaqvi.deviantart.com/

License:  Feel free to use them for personal and commercial projects.

� Some rights reserved NarjisNaqvi - http://narjisnaqvi.deviantart.com/248