=== Plugin Name ===
Contributors: nathanrice, studiopress, wpmuguru
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5553118
Tags: tabs, ui-tabs, genesis, genesiswp, studiopress
Requires at least: 3.2
Tested up to: 3.2.1
Stable tag: 0.9.0

This plugin allows you to create a tabbed section, via a widgets, that can display the featured image, along with the title and excerpt from each post.

== Description ==

This plugin allows you to create a tabbed section, via a widgets, that can display the featured image, along with the title and excerpt from each post.

Choose which categories you want to feature in the tabbed section, which post elements you want to show, and save the widget. Place the widget in the feature section of a Genesis child theme.

Note: This plugin only supports Genesis child themes.

== Installation ==

1. Upload the entire `genesis-tabs` folder to the `/wp-content/plugins/` directory
1. DO NOT change the name of the `genesis-tabs` folder
1. Activate the plugin through the 'Plugins' menu in WordPress
1. In the "Widgets" screen, drag the "Genesis Slider" widget to the widget area of your choice, and configure.

== Changelog ==

= 0.9.0 =
* Beta Release