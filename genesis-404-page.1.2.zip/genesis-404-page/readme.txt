=== Genesis 404 Page ===
Contributors: billerickson
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=EDYM76U6BTE5L
Tags: genesis, genesiswp, 404, 
Requires at least: 3.0
Tested up to: 3.6
Stable tag: 1.2

Customize the content of the 404 Page within the Genesis Theme Framework.

== Description ==

Once installed, you can customize your 404 page's title and content in Genesis > 404 Page. 

Use [genesis-404-search] shortcode to add a search form to the page.

If you'd like to dynamically list content (ex: most recent posts), I recommend you install the [Display Posts Shortcode](http://www.wordpress.org/extend/plugins/display-posts-shortcode/) and use it in the 404 page's content.


== Changelog ==

= 1.2 = 
* Add HTML5 Support

= 1.1 =
* Add Search functionality

= 1.0 = 
* Initial release